function muesta_oculta (id){
    let div= document



}